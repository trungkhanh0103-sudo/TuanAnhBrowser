import SwiftUI

struct EditProfileView: View {
    @EnvironmentObject private var store: ProfileStore
    @Environment(\.dismiss) private var dismiss

    @State private var draft: Profile
    @State private var proxyText: String
    @State private var error: String?
    @StateObject private var checker = ProxyCheck()
    private let originalUUID: UUID

    private let languages = ["vi-VN", "en-US", "en-GB", "ja-JP", "ko-KR", "zh-CN", "zh-TW", "th-TH", "id-ID", "fr-FR", "de-DE", "es-ES", "pt-BR", "ru-RU"]

    init(profile: Profile) {
        _draft = State(initialValue: profile)
        originalUUID = profile.uuid
        var text = ""
        if profile.hasProxy {
            if !profile.proxyUser.isEmpty {
                text = "\(profile.proxyUser):\(profile.proxyPass)@\(profile.proxyHost):\(profile.proxyPort)"
            } else {
                text = "\(profile.proxyHost):\(profile.proxyPort)"
            }
        }
        _proxyText = State(initialValue: text)
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Theme.background.ignoresSafeArea()
                ScrollView {
                    VStack(spacing: 16) {
                        identitySection
                        deviceSection
                        languageSection
                        proxySection
                        timezoneSection
                        privacySection
                        Button("Lưu hồ sơ") { save() }
                            .buttonStyle(BrandButtonStyle())
                        if let error {
                            Text(error)
                                .font(.system(size: 13))
                                .foregroundStyle(Theme.danger)
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                    }
                    .padding(16)
                }
            }
            .navigationTitle(draft.name.isEmpty ? "Hồ sơ" : draft.name)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Hủy") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Lưu") { save() }.fontWeight(.semibold)
                }
            }
        }
    }

    private var identitySection: some View {
        VStack(spacing: 10) {
            SectionHeader(title: "TÊN HỒ SƠ")
            TextField("Ví dụ: Công việc, Cá nhân.", text: $draft.name)
                .textFieldStyle(.plain)
                .font(.system(size: 16))
            HStack(spacing: 8) {
                ForEach(0..<Profile.avatarColors.count, id: \.self) { index in
                    Circle()
                        .fill(Theme.avatarGradient(index))
                        .frame(width: 28, height: 28)
                        .overlay(Circle().stroke(Color.white, lineWidth: draft.color == index ? 3 : 0))
                        .shadow(color: Theme.ink.opacity(draft.color == index ? 0.3 : 0), radius: 3)
                        .onTapGesture { draft.color = index }
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .card()
    }

    private var deviceSection: some View {
        VStack(spacing: 10) {
            SectionHeader(title: "THIẾT BỊ MẪU · UA · UUID · FINGERPRINT")
            Menu {
                ForEach(Devices.all.indices, id: \.self) { index in
                    Button {
                        draft.applyDevice(index)
                    } label: {
                        Text("\(Devices.all[index].name)  ·  \(Devices.all[index].summary)")
                    }
                }
            } label: {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(draft.deviceName)
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundStyle(Theme.ink)
                        Text(Devices.template(at: draft.device).summary)
                            .font(.system(size: 12))
                            .foregroundStyle(Theme.secondary)
                    }
                    Spacer()
                    Image(systemName: "chevron.up.chevron.down")
                        .font(.system(size: 13))
                        .foregroundStyle(Theme.faint)
                }
                .padding(12)
                .background(Theme.background)
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            Picker("Chế độ UA", selection: $draft.uaMode) {
                ForEach(UAMode.allCases) { mode in
                    Text(mode.label).tag(mode)
                }
            }
            .pickerStyle(.segmented)
            Text(draft.uaMode.detail)
                .font(.system(size: 12))
                .foregroundStyle(Theme.secondary)
                .frame(maxWidth: .infinity, alignment: .leading)
            if draft.uaMode == .custom {
                TextField("Mozilla/5.0 ...", text: $draft.customUa, axis: .vertical)
                    .font(.system(size: 12, design: .monospaced))
                    .lineLimit(2...4)
                    .padding(10)
                    .background(Theme.background)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            Text("Đổi thiết bị mẫu = UUID & fingerprint mới")
                .font(.system(size: 11))
                .foregroundStyle(Theme.faint)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .card()
    }

    private var languageSection: some View {
        VStack(spacing: 10) {
            SectionHeader(title: "NGÔN NGỮ & TRANG CHỦ")
            HStack {
                Text("Ngôn ngữ")
                    .font(.system(size: 14))
                    .foregroundStyle(Theme.secondary)
                Spacer()
                Picker("", selection: $draft.lang) {
                    ForEach(languages, id: \.self) { Text($0).tag($0) }
                }
                .tint(Theme.brand)
            }
            TextField("https://www.google.com", text: $draft.home)
                .textFieldStyle(.plain)
                .font(.system(size: 14))
                .keyboardType(.URL)
                .autocorrectionDisabled()
                .textInputAutocapitalization(.never)
        }
        .card()
    }

    private var proxySection: some View {
        VStack(spacing: 10) {
            SectionHeader(title: "LOẠI PROXY")
            Picker("", selection: $draft.proxyType) {
                ForEach(ProxyKind.allCases) { kind in
                    Text(kind.label).tag(kind)
                }
            }
            .pickerStyle(.segmented)
            if draft.proxyType != .direct {
                SectionHeader(title: "ĐỊA CHỈ PROXY")
                TextField("host:port hoặc user:pass@host:port", text: $proxyText)
                    .textFieldStyle(.plain)
                    .font(.system(size: 14, design: .monospaced))
                    .keyboardType(.numbersAndPunctuation)
                    .autocorrectionDisabled()
                    .textInputAutocapitalization(.never)
                    .padding(10)
                    .background(Theme.background)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                Text(draft.proxyType == .http
                     ? "HTTP hỗ trợ user:pass. Để trống = kết nối trực tiếp."
                     : "SOCKS5 chỉ dùng host:port — không hỗ trợ xác thực.")
                    .font(.system(size: 11))
                    .foregroundStyle(Theme.faint)
                    .frame(maxWidth: .infinity, alignment: .leading)
            } else {
                Text("Kết nối trực tiếp · không ẩn IP")
                    .font(.system(size: 12))
                    .foregroundStyle(Theme.warning)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            Button {
                Task { await checkProxy() }
            } label: {
                HStack(spacing: 6) {
                    if checker.checking {
                        ProgressView().tint(Theme.brand)
                    } else {
                        Image(systemName: "checkmark.shield")
                    }
                    Text(checker.checking ? "Đang kiểm tra..." : "Kiểm tra proxy")
                        .font(.system(size: 14, weight: .semibold))
                }
                .foregroundStyle(Theme.brand)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 10)
                .background(Theme.brand.opacity(0.1))
                .clipShape(Capsule())
            }
            .disabled(checker.checking)
            if let info = checker.info {
                proxyResult(info)
            }
        }
        .card()
    }

    private func proxyResult(_ info: ProxyInfo) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            if let error = info.error {
                Label(error, systemImage: "xmark.octagon.fill")
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(Theme.danger)
            } else {
                Text("\(info.flag) \(info.ip)")
                    .font(.system(size: 15, weight: .bold, design: .monospaced))
                    .foregroundStyle(Theme.ink)
                Text("Quốc gia: \(info.country)")
                    .font(.system(size: 12))
                    .foregroundStyle(Theme.secondary)
                Text("Múi giờ: \(info.timezone)")
                    .font(.system(size: 12))
                    .foregroundStyle(Theme.secondary)
                Text("ISP: \(info.isp)")
                    .font(.system(size: 12))
                    .foregroundStyle(Theme.secondary)
                if let ms = info.latencyMs {
                    Text(String(format: "Độ trễ: %.0f ms", ms))
                        .font(.system(size: 12))
                        .foregroundStyle(Theme.secondary)
                }
                Text(info.isMobile ? "Loại: mạng di động" : "Loại: dân cư")
                    .font(.system(size: 12))
                    .foregroundStyle(Theme.secondary)
                if draft.proxyType == .direct {
                    warn("Cảnh báo: đang KHÔNG dùng proxy")
                }
                if info.isProxy {
                    warn("Cảnh báo: IP bị đánh dấu là proxy/VPN")
                }
                if info.isHosting {
                    warn("Cảnh báo: IP thuộc trung tâm dữ liệu/hosting")
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(12)
        .background(Theme.background)
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }

    private func warn(_ text: String) -> some View {
        Label(text, systemImage: "exclamationmark.triangle.fill")
            .font(.system(size: 12, weight: .medium))
            .foregroundStyle(Theme.warning)
    }

    private var timezoneSection: some View {
        VStack(spacing: 10) {
            SectionHeader(title: "MÚI GIỜ (TỰ ĐỘNG THEO IP PROXY)")
            TextField("Tự động (khuyên dùng)", text: $draft.tz)
                .textFieldStyle(.plain)
                .font(.system(size: 14, design: .monospaced))
                .autocorrectionDisabled()
                .textInputAutocapitalization(.never)
            Text("Để trống: mỗi lần mở hồ sơ app tự dò múi giờ theo IP proxy (khuyên dùng). Nhập tay chỉ khi cần cố định. Ví dụ: Asia/Ho_Chi_Minh")
                .font(.system(size: 11))
                .foregroundStyle(Theme.faint)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .card()
    }

    private var privacySection: some View {
        VStack(spacing: 10) {
            SectionHeader(title: "QUYỀN RIÊNG TƯ")
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("WebRTC")
                        .font(.system(size: 14, weight: .medium))
                    Text("Relay chỉ cho phép đi qua TURN để giấu IP thật.")
                        .font(.system(size: 11))
                        .foregroundStyle(Theme.faint)
                }
                Spacer()
                Picker("", selection: $draft.rtc) {
                    ForEach(RTCMode.allCases) { mode in
                        Text(mode.label).tag(mode)
                    }
                }
                .tint(Theme.brand)
            }
            Toggle(isOn: $draft.blockImg) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Chặn ảnh")
                        .font(.system(size: 14, weight: .medium))
                    Text("Tải trang nhanh hơn, tiết kiệm dữ liệu")
                        .font(.system(size: 11))
                        .foregroundStyle(Theme.faint)
                }
            }
            .tint(Theme.brand)
        }
        .card()
    }

    private func parsedProxyFromText() -> ParsedProxy? {
        ParsedProxy(text: proxyText, kind: draft.proxyType)
    }

    private func checkProxy() async {
        error = nil
        if draft.proxyType != .direct {
            guard let parsed = parsedProxyFromText() else {
                error = "Sai định dạng. Ví dụ: host:port hoặc user:pass@host:port"
                return
            }
            if draft.proxyType == .socks5 && !parsed.user.isEmpty {
                error = "SOCKS5 không hỗ trợ user:pass — bỏ phần xác thực hoặc chọn HTTP"
                return
            }
            _ = await checker.check(parsed)
        } else {
            _ = await checker.check(nil)
        }
    }

    private func save() {
        error = nil
        if draft.name.trimmingCharacters(in: .whitespaces).isEmpty {
            draft.name = "Hồ sơ"
        }
        if draft.proxyType != .direct {
            let trimmed = proxyText.trimmingCharacters(in: .whitespacesAndNewlines)
            if trimmed.isEmpty {
                draft.proxyType = .direct
                draft.proxyHost = ""
                draft.proxyPort = 0
                draft.proxyUser = ""
                draft.proxyPass = ""
            } else {
                guard let parsed = parsedProxyFromText() else {
                    error = "Sai định dạng. Ví dụ: host:port hoặc user:pass@host:port"
                    return
                }
                if draft.proxyType == .socks5 && !parsed.user.isEmpty {
                    error = "SOCKS5 không hỗ trợ user:pass — bỏ phần xác thực hoặc chọn HTTP"
                    return
                }
                draft.proxyHost = parsed.host
                draft.proxyPort = parsed.port
                draft.proxyUser = parsed.user
                draft.proxyPass = parsed.pass
            }
        } else {
            draft.proxyHost = ""
            draft.proxyPort = 0
            draft.proxyUser = ""
            draft.proxyPass = ""
        }
        let tz = draft.tz.trimmingCharacters(in: .whitespacesAndNewlines)
        if !tz.isEmpty && TimeZone(identifier: tz) == nil {
            error = "Múi giờ không hợp lệ. Ví dụ: Asia/Ho_Chi_Minh"
            return
        }
        draft.tz = tz
        if draft.home.trimmingCharacters(in: .whitespaces).isEmpty {
            draft.home = "https://www.google.com"
        } else if !draft.home.hasPrefix("http") {
            draft.home = "https://" + draft.home
        }
        draft.spoofUa = draft.uaMode != .real
        if draft.uuid != originalUUID {
            store.wipeData(uuid: originalUUID)
            store.profiles.removeAll { $0.uuid == originalUUID }
        }
        store.upsert(draft)
        dismiss()
    }
}