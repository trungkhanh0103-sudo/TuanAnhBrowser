import SwiftUI
import UniformTypeIdentifiers

struct JSONDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.json] }
    var data: Data

    init(data: Data) { self.data = data }

    init(configuration: ReadConfiguration) throws {
        data = configuration.file.regularFileContents ?? Data()
    }

    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: data)
    }
}

private enum ProfilesAlert {
    case delete(Profile)
    case exportWarning
    case info(String)
}

struct ProfilesView: View {
    @EnvironmentObject private var store: ProfileStore
    @State private var editing: Profile?
    @State private var opening: Profile?
    @State private var alert: ProfilesAlert?
    @State private var showApps = false
    @State private var showPerf = false
    @State private var exporting = false
    @State private var importing = false
    @State private var exportDocument = JSONDocument(data: Data())
    @State private var pendingAppsURL: String?

    var body: some View {
        NavigationStack {
            ZStack {
                Theme.background.ignoresSafeArea()
                ScrollView {
                    VStack(spacing: 16) {
                        header
                        if store.profiles.isEmpty {
                            emptyState
                        } else {
                            ForEach(store.profiles) { profile in
                                profileCard(profile)
                            }
                        }
                        Text("TUANANH BROWSER · ẨN DANH · v2.10")
                            .font(.system(size: 11, weight: .medium))
                            .tracking(1)
                            .foregroundStyle(Theme.faint)
                            .padding(.top, 12)
                    }
                    .padding(16)
                }
            }
            .navigationBarHidden(true)
            .sheet(item: $editing) { profile in
                EditProfileView(profile: profile)
            }
            .fullScreenCover(item: $opening, onDismiss: { pendingAppsURL = nil }) { profile in
                BrowserContainerView(profile: profile, initialURL: pendingAppsURL)
            }
            .sheet(isPresented: $showApps) {
                AppsCatalogView(onOpen: { url in openAppsLink(url) })
            }
            .sheet(isPresented: $showPerf) { PerfView() }
            .alert(alertTitle, isPresented: Binding(get: { alert != nil }, set: { if !$0 { alert = nil } }), presenting: alert) { kind in
                switch kind {
                case .delete(let profile):
                    Button("Xóa", role: .destructive) {
                        store.delete(profile)
                        alert = nil
                    }
                    Button("Hủy", role: .cancel) { alert = nil }
                case .exportWarning:
                    Button("Tiếp tục") {
                        if let data = try? store.exportData() {
                            exportDocument = JSONDocument(data: data)
                            exporting = true
                        }
                        alert = nil
                    }
                    Button("Hủy", role: .cancel) { alert = nil }
                case .info:
                    Button("OK") { alert = nil }
                }
            } message: { kind in
                switch kind {
                case .delete(let profile):
                    Text("Cookie và dữ liệu của hồ sơ \"\(profile.name)\" sẽ bị xóa vĩnh viễn.")
                case .exportWarning:
                    Text("File sao lưu chứa proxy kèm user:pass ở dạng văn bản thường. Hãy cất file ở nơi an toàn và đừng gửi cho người khác.")
                case .info(let text):
                    Text(text)
                }
            }
            .fileExporter(isPresented: $exporting, document: exportDocument, contentType: .json, defaultFilename: "tuananh-profiles.json") { result in
                if case .success = result { alert = .info("Đã sao lưu \(store.profiles.count) hồ sơ") }
            }
            .fileImporter(isPresented: $importing, allowedContentTypes: [.json]) { result in
                handleImport(result)
            }
        }
    }

    private var alertTitle: String {
        switch alert {
        case .delete: return "Xóa hồ sơ?"
        case .exportWarning: return "Sao lưu hồ sơ"
        case .info, .none: return "Thông báo"
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("HỒ SƠ DUYỆT WEB")
                        .font(.system(size: 24, weight: .heavy))
                        .foregroundStyle(Theme.ink)
                    Text("Đa hồ sơ · đa danh tính · ẩn danh")
                        .font(.system(size: 13))
                        .foregroundStyle(Theme.secondary)
                }
                Spacer()
                Menu {
                    Button { alert = .exportWarning } label: { Label("Sao lưu hồ sơ", systemImage: "square.and.arrow.up") }
                    Button { importing = true } label: { Label("Khôi phục từ file", systemImage: "square.and.arrow.down") }
                    Button { showApps = true } label: { Label("Tải App", systemImage: "square.grid.2x2") }
                    Button { showPerf = true } label: { Label("Hiệu năng & Cấu hình", systemImage: "gauge.with.dots.needle.67percent") }
                } label: {
                    Image(systemName: "ellipsis.circle.fill")
                        .font(.system(size: 26))
                        .foregroundStyle(Theme.brand)
                }
                Button {
                    editing = Profile.new(index: Int.random(in: 0..<Devices.all.count))
                } label: {
                    Image(systemName: "plus.circle.fill")
                        .font(.system(size: 30))
                        .foregroundStyle(Theme.brand)
                }
            }
            Text("Mỗi hồ sơ là một danh tính số riêng biệt")
                .font(.system(size: 12))
                .foregroundStyle(Theme.faint)
        }
        .card()
    }

    private var emptyState: some View {
        VStack(spacing: 14) {
            Image(systemName: "person.2.crop.square.stack")
                .font(.system(size: 44))
                .foregroundStyle(Theme.faint)
            Text("Chưa có hồ sơ nào")
                .font(.system(size: 17, weight: .semibold))
                .foregroundStyle(Theme.ink)
            Text("Tạo hồ sơ đầu tiên để bắt đầu duyệt web với danh tính riêng")
                .font(.system(size: 13))
                .foregroundStyle(Theme.secondary)
                .multilineTextAlignment(.center)
            Button("Tạo hồ sơ đầu tiên") {
                editing = Profile.new(index: Devices.windowsIndex)
            }
            .buttonStyle(BrandButtonStyle())
            .frame(maxWidth: 240)
        }
        .card(padding: 28)
    }

    private func profileCard(_ profile: Profile) -> some View {
        Button {
            store.touch(profile.id)
            opening = profile
        } label: {
            HStack(spacing: 14) {
                ZStack {
                    Circle().fill(Theme.avatarGradient(profile.color))
                    Text(String(profile.name.prefix(1)).uppercased())
                        .font(.system(size: 22, weight: .bold))
                        .foregroundStyle(.white)
                }
                .frame(width: 52, height: 52)
                VStack(alignment: .leading, spacing: 4) {
                    Text(profile.name)
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(Theme.ink)
                    Text(profile.deviceName)
                        .font(.system(size: 12))
                        .foregroundStyle(Theme.secondary)
                    Text(profile.proxySummary)
                        .font(.system(size: 11))
                        .foregroundStyle(profile.hasProxy ? Theme.brand : Theme.faint)
                        .lineLimit(1)
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 6) {
                    Image(systemName: "chevron.right.circle.fill")
                        .font(.system(size: 22))
                        .foregroundStyle(Theme.brand.opacity(0.7))
                    if !profile.tabs.isEmpty {
                        Text("\(profile.tabs.count) thẻ")
                            .font(.system(size: 11, weight: .medium))
                            .foregroundStyle(Theme.faint)
                    }
                }
            }
            .card()
        }
        .buttonStyle(.plain)
        .contextMenu {
            Button { editing = profile } label: { Label("Sửa hồ sơ", systemImage: "pencil") }
            Button(role: .destructive) { alert = .delete(profile) } label: { Label("Xóa hồ sơ", systemImage: "trash") }
        }
    }

    private func openAppsLink(_ url: String) {
        guard let first = store.profiles.first else {
            alert = .info("Hãy tạo một hồ sơ trước")
            return
        }
        pendingAppsURL = url
        showApps = false
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
            opening = first
        }
    }

    private func handleImport(_ result: Result<URL, Error>) {
        switch result {
        case .success(let url):
            let accessing = url.startAccessingSecurityScopedResource()
            defer { if accessing { url.stopAccessingSecurityScopedResource() } }
            do {
                let data = try Data(contentsOf: url)
                let count = try store.importData(data)
                alert = .info("Đã khôi phục \(count) hồ sơ")
            } catch {
                alert = .info("Lỗi: file không hợp lệ")
            }
        case .failure:
            alert = .info("Không đọc được file")
        }
    }
}

