import SwiftUI
import UIKit
import WebKit
import Darwin
import os

struct PerfView: View {
    @EnvironmentObject private var store: ProfileStore
    @Environment(\.dismiss) private var dismiss
    @State private var pingTarget = "1.1.1.1:443"
    @State private var pinging = false
    @State private var pingResult: String?
    @State private var message: String?
    @State private var thermal = ProcessInfo.processInfo.thermalState
    @State private var batteryLevel = UIDevice.current.batteryLevel
    @State private var batteryState = UIDevice.current.batteryState

    private let timer = Timer.publish(every: 3, on: .main, in: .common).autoconnect()

    var body: some View {
        NavigationStack {
            ZStack {
                Theme.background.ignoresSafeArea()
                ScrollView {
                    VStack(spacing: 16) {
                        specsCard
                        pingCard
                        fpsCard
                        toolsCard
                        Text("iOS tự quản lý hiệu năng và bộ nhớ — không có ép xung như Android. Các công cụ ở trên chỉ dọn cache và đo thông số thật.")
                            .font(.system(size: 11))
                            .foregroundStyle(Theme.faint)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    .padding(16)
                }
            }
            .navigationTitle("Hiệu năng & Cấu hình máy")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Đóng") { dismiss() }
                }
            }
            .onAppear {
                UIDevice.current.isBatteryMonitoringEnabled = true
                refreshVitals()
            }
            .onReceive(timer) { _ in refreshVitals() }
            .alert("Thông báo", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
                Button("OK") { message = nil }
            } message: {
                Text(message ?? "")
            }
        }
    }

    private var specsCard: some View {
        VStack(spacing: 10) {
            SectionHeader(title: "THÔNG SỐ MÁY")
            specRow("Thiết bị", Self.machineName())
            specRow("Hệ điều hành", "iOS \(UIDevice.current.systemVersion)")
            specRow("RAM", String(format: "%.1f GB", Double(ProcessInfo.processInfo.physicalMemory) / 1_073_741_824))
            specRow("CPU", "\(ProcessInfo.processInfo.activeProcessorCount) nhân")
            specRow("Màn hình", "\(Int(UIScreen.main.nativeBounds.width))×\(Int(UIScreen.main.nativeBounds.height)) · tối đa \(UIScreen.main.maximumFramesPerSecond)Hz")
            specRow("RAM khả dụng cho app", String(format: "%.0f MB", Double(os_proc_available_memory()) / 1_048_576))
            specRow("Nhiệt độ", thermalLabel)
            specRow("Pin", batteryLabel)
        }
        .card()
    }

    private func specRow(_ title: String, _ value: String) -> some View {
        HStack {
            Text(title)
                .font(.system(size: 13))
                .foregroundStyle(Theme.secondary)
            Spacer()
            Text(value)
                .font(.system(size: 13, weight: .medium))
                .foregroundStyle(Theme.ink)
        }
    }

    private var thermalLabel: String {
        switch thermal {
        case .nominal: return "Bình thường"
        case .fair: return "Ấm nhẹ"
        case .serious: return "Nóng"
        case .critical: return "Rất nóng"
        @unknown default: return "Không rõ"
        }
    }

    private var batteryLabel: String {
        let percent = batteryLevel >= 0 ? String(format: "%.0f%%", batteryLevel * 100) : "Không rõ"
        switch batteryState {
        case .charging: return percent + " · Đang sạc"
        case .full: return percent + " · Đầy"
        case .unplugged: return percent + " · Dùng pin"
        default: return percent
        }
    }

    private var pingCard: some View {
        VStack(spacing: 10) {
            SectionHeader(title: "ĐO PING · ĐỘ TRỄ TCP THẬT")
            TextField("host:port · ví dụ 1.1.1.1:443", text: $pingTarget)
                .textFieldStyle(.plain)
                .font(.system(size: 14, design: .monospaced))
                .keyboardType(.numbersAndPunctuation)
                .autocorrectionDisabled()
                .textInputAutocapitalization(.never)
            Button {
                Task { await runPing() }
            } label: {
                HStack(spacing: 6) {
                    if pinging { ProgressView().tint(.white) }
                    Text(pinging ? "Đang đo..." : "Đo ping")
                }
            }
            .buttonStyle(BrandButtonStyle())
            .disabled(pinging)
            if let pingResult {
                Text(pingResult)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(Theme.brand)
            }
            Text("Ping phụ thuộc khoảng cách máy chủ/proxy và chất lượng mạng — không có nút \"giảm\" ảo. Đây là số đo TCP thật từ thiết bị. Muốn ping thấp: chọn proxy gần bạn hơn.")
                .font(.system(size: 11))
                .foregroundStyle(Theme.faint)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .card()
    }

    private var fpsCard: some View {
        VStack(spacing: 10) {
            SectionHeader(title: "TẦN SỐ QUÉT")
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text("Tăng FPS · ProMotion")
                        .font(.system(size: 14, weight: .medium))
                    Text("App đã bật CADisableMinimumFrameDuration — màn hình ProMotion sẽ chạy ở tần số cao nhất khi cần.")
                        .font(.system(size: 11))
                        .foregroundStyle(Theme.faint)
                }
                Spacer()
                Text("\(UIScreen.main.maximumFramesPerSecond)Hz")
                    .font(.system(size: 17, weight: .bold))
                    .foregroundStyle(Theme.brand)
            }
        }
        .card()
    }

    private var toolsCard: some View {
        VStack(spacing: 10) {
            SectionHeader(title: "BỘ NHỚ")
            Button {
                URLCache.shared.removeAllCachedResponses()
                for profile in store.profiles { store.clearCache(profile) }
                message = "Đã xóa cache WebView của mọi hồ sơ"
            } label: {
                Label("Xóa cache mọi hồ sơ", systemImage: "trash")
            }
            .buttonStyle(BrandButtonStyle(color: Theme.secondary))
            Text("Xóa cache không đụng cookie/danh tính. iOS tự thu hồi RAM khi cần.")
                .font(.system(size: 11))
                .foregroundStyle(Theme.faint)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .card()
    }

    private func refreshVitals() {
        thermal = ProcessInfo.processInfo.thermalState
        batteryLevel = UIDevice.current.batteryLevel
        batteryState = UIDevice.current.batteryState
    }

    private func runPing() async {
        let parts = pingTarget.split(separator: ":")
        guard let host = parts.first.map(String.init), !host.isEmpty else {
            pingResult = "Nhập host trước đã."
            return
        }
        let port = parts.count > 1 ? UInt16(parts[1]) ?? 443 : 443
        pinging = true
        pingResult = nil
        let ms = await ProxyCheck.ping(host: host, port: port)
        pinging = false
        if let ms {
            pingResult = String(format: "%.0f ms · %@", ms, host)
        } else {
            pingResult = "Không kết nối được \(host) (mạng yếu hoặc máy chủ chặn)."
        }
    }

    static func machineName() -> String {
        var systemInfo = utsname()
        uname(&systemInfo)
        let mirror = Mirror(reflecting: systemInfo.machine)
        let identifier = mirror.children.reduce("") { partial, element in
            guard let value = element.value as? Int8, value != 0 else { return partial }
            return partial + String(UnicodeScalar(UInt8(value)))
        }
        return identifier.isEmpty ? UIDevice.current.model : identifier
    }
}