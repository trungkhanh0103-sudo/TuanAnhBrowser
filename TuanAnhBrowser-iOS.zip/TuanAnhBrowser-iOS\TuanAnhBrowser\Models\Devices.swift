import Foundation

struct DeviceTemplate {
    let name: String
    let ua: String
    let platform: String
    let sw: Int
    let sh: Int
    let dpr: Double
    let touch: Int
    let cores: Int
    let mem: Int
    let gpuV: String
    let gpuR: String

    var summary: String {
        "\(sw)×\(sh) · \(mem)GB · \(platform)"
    }
}

enum Devices {
    static func safariUA(os: String, version: String) -> String {
        "Mozilla/5.0 (iPhone; CPU iPhone OS \(os) like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/\(version) Mobile/15E148 Safari/604.1"
    }

    static func chromeMobileUA(android: String, model: String) -> String {
        "Mozilla/5.0 (Linux; Android \(android); \(model)) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36"
    }

    static let windowsUA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"

    static func iphone(_ name: String, os: String, version: String, sw: Int, sh: Int, dpr: Double, cores: Int, mem: Int) -> DeviceTemplate {
        DeviceTemplate(
            name: name, ua: safariUA(os: os, version: version), platform: "iPhone",
            sw: sw, sh: sh, dpr: dpr, touch: 5, cores: cores, mem: mem,
            gpuV: "Apple Inc.", gpuR: "Apple GPU"
        )
    }

    static func android(_ name: String, model: String, android: String, sw: Int, sh: Int, dpr: Double, cores: Int, mem: Int, gpu: String) -> DeviceTemplate {
        let isAdreno = gpu.hasPrefix("Adreno")
        let vendor = isAdreno ? "Google Inc. (Qualcomm)" : "Google Inc. (ARM)"
        let renderer = "ANGLE (\(isAdreno ? "Qualcomm" : "ARM"), \(gpu), OpenGL ES 3.2)"
        return DeviceTemplate(
            name: name, ua: chromeMobileUA(android: android, model: model), platform: "Linux armv8l",
            sw: sw, sh: sh, dpr: dpr, touch: 5, cores: cores, mem: mem,
            gpuV: vendor, gpuR: renderer
        )
    }

    static let windows = DeviceTemplate(
        name: "Máy tính Windows", ua: windowsUA, platform: "Win32",
        sw: 1920, sh: 1080, dpr: 1, touch: 0, cores: 8, mem: 8,
        gpuV: "Google Inc. (NVIDIA)",
        gpuR: "ANGLE (NVIDIA, NVIDIA GeForce GTX 1650 Direct3D11 vs_5_0 ps_5_0, D3D11)"
    )

    static let all: [DeviceTemplate] = [
        iphone("iPhone 7", os: "15_8", version: "15.6", sw: 375, sh: 667, dpr: 2, cores: 4, mem: 2),
        iphone("iPhone 8", os: "15_8", version: "15.6", sw: 375, sh: 667, dpr: 2, cores: 4, mem: 2),
        iphone("iPhone X", os: "16_7", version: "16.6", sw: 375, sh: 812, dpr: 3, cores: 6, mem: 3),
        iphone("iPhone 11", os: "17_5", version: "17.5", sw: 414, sh: 896, dpr: 2, cores: 6, mem: 4),
        iphone("iPhone 12", os: "17_5", version: "17.5", sw: 390, sh: 844, dpr: 3, cores: 6, mem: 4),
        iphone("iPhone 13", os: "17_5", version: "17.5", sw: 390, sh: 844, dpr: 3, cores: 6, mem: 4),
        iphone("iPhone 14", os: "17_5", version: "17.5", sw: 390, sh: 844, dpr: 3, cores: 6, mem: 6),
        iphone("iPhone 14 Pro Max", os: "17_5", version: "17.5", sw: 430, sh: 932, dpr: 3, cores: 6, mem: 6),
        iphone("iPhone 15", os: "17_5", version: "17.5", sw: 393, sh: 852, dpr: 3, cores: 6, mem: 6),
        iphone("iPhone 15 Pro Max", os: "18_0", version: "18.0", sw: 430, sh: 932, dpr: 3, cores: 6, mem: 8),
        iphone("iPhone 16 Pro Max", os: "18_0", version: "18.0", sw: 440, sh: 956, dpr: 3, cores: 6, mem: 8),
        iphone("iPhone 17 Pro Max", os: "26_0", version: "26.0", sw: 440, sh: 956, dpr: 3, cores: 6, mem: 12),
        iphone("iPhone 18 Pro Max", os: "26_0", version: "26.0", sw: 440, sh: 956, dpr: 3, cores: 6, mem: 12),
        android("Galaxy S21", model: "SM-G991B", android: "13", sw: 360, sh: 800, dpr: 3, cores: 8, mem: 8, gpu: "Adreno (TM) 660"),
        android("Galaxy S22 Ultra", model: "SM-S908B", android: "14", sw: 360, sh: 772, dpr: 4, cores: 8, mem: 12, gpu: "Adreno (TM) 730"),
        android("Galaxy S23", model: "SM-S911B", android: "14", sw: 360, sh: 780, dpr: 3, cores: 8, mem: 8, gpu: "Adreno (TM) 740"),
        android("Galaxy S24 Ultra", model: "SM-S928B", android: "14", sw: 384, sh: 824, dpr: 3.75, cores: 8, mem: 12, gpu: "Adreno (TM) 750"),
        android("Galaxy Z Fold5", model: "SM-F946B", android: "14", sw: 360, sh: 845, dpr: 3, cores: 8, mem: 12, gpu: "Adreno (TM) 740"),
        android("Pixel 7", model: "Pixel 7", android: "14", sw: 412, sh: 915, dpr: 2.625, cores: 8, mem: 8, gpu: "Mali-G710 MC10"),
        android("Pixel 8 Pro", model: "Pixel 8 Pro", android: "14", sw: 448, sh: 997, dpr: 3, cores: 8, mem: 12, gpu: "Mali-G715-Immortalis MC10"),
        android("Pixel 9 Pro", model: "Pixel 9 Pro", android: "15", sw: 427, sh: 952, dpr: 3, cores: 8, mem: 16, gpu: "Mali-G715-Immortalis MC10"),
        android("Xiaomi 13", model: "2211133C", android: "14", sw: 393, sh: 873, dpr: 2.75, cores: 8, mem: 12, gpu: "Adreno (TM) 740"),
        android("Redmi Note 13", model: "2312DRA50G", android: "14", sw: 393, sh: 873, dpr: 2.75, cores: 8, mem: 8, gpu: "Mali-G57 MC2"),
        android("OPPO Find X7", model: "PHZ110", android: "14", sw: 393, sh: 872, dpr: 2.75, cores: 8, mem: 16, gpu: "Mali-G720-Immortalis MC12"),
        android("Vivo X100", model: "V2324A", android: "14", sw: 393, sh: 873, dpr: 2.75, cores: 8, mem: 16, gpu: "Mali-G720-Immortalis MC12"),
        android("Realme GT5", model: "RMX3840", android: "14", sw: 393, sh: 873, dpr: 2.75, cores: 8, mem: 16, gpu: "Adreno (TM) 740"),
        windows
    ]

    static let windowsIndex = all.count - 1

    static func template(at index: Int) -> DeviceTemplate {
        guard all.indices.contains(index) else { return all[0] }
        return all[index]
    }
}