import SwiftUI
import WebKit
import UIKit

struct BrowserContainerView: View {
    let profile: Profile
    var initialURL: String?
    @EnvironmentObject private var store: ProfileStore
    @Environment(\.dismiss) private var dismiss
    @State private var session: BrowserSession?
    @State private var proxyInfo: ProxyInfo?
    @State private var statusText = "Đang chuẩn bị hồ sơ..."
    @State private var setupFailed = false

    var body: some View {
        ZStack {
            Theme.background.ignoresSafeArea()
            if let session {
                BrowserScreen(session: session, proxyInfo: proxyInfo)
            } else {
                VStack(spacing: 18) {
                    ZStack {
                        Circle().fill(Theme.gradient.opacity(0.15)).frame(width: 84, height: 84)
                        if setupFailed {
                            Image(systemName: "wifi.exclamationmark")
                                .font(.system(size: 34))
                                .foregroundStyle(Theme.danger)
                        } else {
                            ProgressView().controlSize(.large).tint(Theme.brand)
                        }
                    }
                    Text(setupFailed ? "Không kết nối được proxy" : statusText)
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(Theme.ink)
                    Text(profile.name + " · " + profile.deviceName)
                        .font(.system(size: 13))
                        .foregroundStyle(Theme.secondary)
                    if setupFailed {
                        HStack(spacing: 12) {
                            Button("Thử lại") { Task { await setup() } }
                                .buttonStyle(BrandButtonStyle())
                            Button("Đóng") { dismiss() }
                                .font(.system(size: 15, weight: .semibold))
                                .foregroundStyle(Theme.secondary)
                                .padding(.horizontal, 20)
                        }
                        .frame(maxWidth: 320)
                    }
                }
                .padding(24)
            }
        }
        .task { await setup() }
        .onDisappear { session?.persistTabs() }
    }

    private func setup() async {
        setupFailed = false
        session = nil
        store.touch(profile.id)
        var runtimeTz = profile.tz
        if profile.hasProxy {
            statusText = "Đang kết nối qua proxy..."
            let checker = ProxyCheck()
            let info = await checker.check(ParsedProxy(profile))
            proxyInfo = info
            if info.error != nil && profile.tz.isEmpty {
                statusText = "Không lấy được múi giờ từ proxy — dùng múi giờ máy"
            }
            if profile.tz.isEmpty {
                runtimeTz = info.timezone
            }
        } else {
            statusText = "Kết nối trực tiếp · không ẩn IP"
        }
        let newSession = BrowserSession(profile: profile, runtimeTz: runtimeTz, store: store)
        if let initialURL, !initialURL.isEmpty {
            newSession.addTab(urlString: initialURL)
        }
        session = newSession
    }
}

struct BrowserScreen: View {
    @ObservedObject var session: BrowserSession
    let proxyInfo: ProxyInfo?
    @EnvironmentObject private var store: ProfileStore
    @Environment(\.dismiss) private var dismiss
    @FocusState private var addressFocused: Bool
    @State private var showApps = false
    @State private var confirmClearCookies = false

    private var activeTab: BrowserTab? { session.activeTab }

    var body: some View {
        VStack(spacing: 0) {
            proxyBar
            addressBar
            if let tab = activeTab, tab.isLoading {
                ProgressView(value: tab.progress)
                    .progressViewStyle(.linear)
                    .tint(Theme.brand)
                    .frame(height: 2)
            }
            ZStack {
                Color.white
                if let tab = activeTab {
                    TabWebView(tab: tab)
                        .id(tab.id)
                }
            }
            .frame(maxHeight: .infinity)
            bottomBar
        }
        .background(Theme.background)
        .sheet(isPresented: $session.showTabs) { tabsSheet }
        .sheet(isPresented: $session.showLinks) { linksSheet }
        .sheet(isPresented: $showApps) {
            AppsCatalogView(onOpen: { url in
                showApps = false
                session.addTab(urlString: url)
            })
        }
        .sheet(isPresented: Binding(get: { session.savedDownload != nil }, set: { if !$0 { session.savedDownload = nil } })) {
            if let url = session.savedDownload {
                ShareSheet(items: [url])
            }
        }
        .alert("Thông báo", isPresented: Binding(get: { session.alertMessage != nil }, set: { if !$0 { session.alertMessage = nil } })) {
            Button("OK") { session.alertMessage = nil }
        } message: {
            Text(session.alertMessage ?? "")
        }
        .confirmationDialog("Xóa cookie của hồ sơ?", isPresented: $confirmClearCookies, titleVisibility: .visible) {
            Button("Xóa", role: .destructive) {
                store.clearCookies(session.profile)
                activeTab?.webView.reload()
                session.alertMessage = "Đã xóa cookie và dữ liệu web"
            }
            Button("Hủy", role: .cancel) {}
        } message: {
            Text("Xóa toàn bộ cookie và dữ liệu web của hồ sơ này.")
        }
    }

    private var proxyBar: some View {
        HStack(spacing: 6) {
            Image(systemName: session.hasProxy ? "checkmark.shield.fill" : "exclamationmark.shield.fill")
                .font(.system(size: 11))
            if let info = proxyInfo, info.error == nil, session.hasProxy {
                Text("\(info.flag) \(info.ip) · \(info.country)")
                    .font(.system(size: 11, weight: .medium))
                    .lineLimit(1)
                if !session.profile.tz.isEmpty || !info.timezone.isEmpty {
                    Text("· \(session.profile.tz.isEmpty ? info.timezone : session.profile.tz)")
                        .font(.system(size: 11))
                        .lineLimit(1)
                }
            } else if session.hasProxy {
                Text(session.profile.proxySummary)
                    .font(.system(size: 11, weight: .medium))
                    .lineLimit(1)
                if let error = proxyInfo?.error {
                    Text("· \(error)")
                        .font(.system(size: 11))
                        .foregroundStyle(Theme.warning)
                        .lineLimit(1)
                }
            } else {
                Text("Kết nối trực tiếp · không ẩn IP")
                    .font(.system(size: 11, weight: .medium))
            }
            Spacer()
            Text("WebRTC \(session.profile.rtc == .off ? "tắt" : "relay")")
                .font(.system(size: 10))
                .foregroundStyle(Theme.faint)
        }
        .foregroundStyle(session.hasProxy ? Theme.brand : Theme.warning)
        .padding(.horizontal, 14)
        .padding(.vertical, 7)
        .background(Theme.background)
    }

    private var addressBar: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 13))
                .foregroundStyle(Theme.faint)
            TextField("Tìm kiếm hoặc nhập địa chỉ", text: $session.addressText)
                .font(.system(size: 14))
                .keyboardType(.webSearch)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .focused($addressFocused)
                .submitLabel(.go)
                .onSubmit {
                    session.navigate(session.addressText)
                    addressFocused = false
                }
            if activeTab?.isLoading == true {
                Button { session.stopLoading() } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(Theme.secondary)
                }
            } else {
                Button { session.reload() } label: {
                    Image(systemName: "arrow.clockwise")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(Theme.secondary)
                }
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .background(Color.white)
        .clipShape(Capsule())
        .shadow(color: Theme.ink.opacity(0.08), radius: 6, x: 0, y: 2)
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(Theme.background)
    }

    private var bottomBar: some View {
        HStack {
            Button { session.goBack() } label: {
                Image(systemName: "chevron.left")
                    .font(.system(size: 18, weight: .medium))
            }
            .disabled(activeTab?.canGoBack != true)
            Spacer()
            Button { session.goForward() } label: {
                Image(systemName: "chevron.right")
                    .font(.system(size: 18, weight: .medium))
            }
            .disabled(activeTab?.canGoForward != true)
            Spacer()
            Button { session.goHome() } label: {
                Image(systemName: "house")
                    .font(.system(size: 18, weight: .medium))
            }
            Spacer()
            Button { session.showTabs = true } label: {
                ZStack {
                    Image(systemName: "square.on.square")
                        .font(.system(size: 18, weight: .medium))
                    Text("\(session.tabs.count)")
                        .font(.system(size: 9, weight: .bold))
                        .foregroundStyle(.white)
                        .padding(3)
                        .background(Theme.brand)
                        .clipShape(Circle())
                        .offset(x: 12, y: -10)
                }
            }
            Spacer()
            Menu {
                Button { session.showLinks = true } label: { Label("Danh sách link", systemImage: "link") }
                Button { showApps = true } label: { Label("Tải App", systemImage: "square.grid.2x2") }
                Button { session.addCurrentLink() } label: { Label("Thêm link hiện tại", systemImage: "plus.circle") }
                Button {
                    UIPasteboard.general.string = activeTab?.url ?? ""
                    session.alertMessage = "Đã sao chép"
                } label: { Label("Sao chép liên kết", systemImage: "doc.on.doc") }
                Button {
                    session.toggleDesktop()
                } label: {
                    Label(activeTab?.desktop == true ? "Trang web cho di động" : "Trang web cho máy tính", systemImage: "desktopcomputer")
                }
                Divider()
                Button {
                    store.clearCache(session.profile)
                    session.alertMessage = "Đã xóa cache WebView"
                } label: { Label("Xóa cache", systemImage: "trash.circle") }
                Button(role: .destructive) {
                    confirmClearCookies = true
                } label: { Label("Xóa cookie của hồ sơ", systemImage: "xmark.bin") }
                Divider()
                Button(role: .destructive) {
                    session.persistTabs()
                    dismiss()
                } label: { Label("Thoát hồ sơ", systemImage: "rectangle.portrait.and.arrow.right") }
            } label: {
                Image(systemName: "ellipsis.circle")
                    .font(.system(size: 20, weight: .medium))
            }
        }
        .foregroundStyle(Theme.ink)
        .tint(Theme.brand)
        .padding(.horizontal, 24)
        .padding(.vertical, 12)
        .background(Color.white)
        .shadow(color: Theme.ink.opacity(0.06), radius: 8, x: 0, y: -2)
    }

    private var tabsSheet: some View {
        NavigationStack {
            ZStack {
                Theme.background.ignoresSafeArea()
                ScrollView {
                    VStack(spacing: 10) {
                        ForEach(session.tabs) { tab in
                            TabRow(tab: tab, active: tab.id == session.activeTabID,
                                   onOpen: {
                                session.activate(tab.id)
                                session.showTabs = false
                            }, onClose: {
                                session.closeTab(tab.id)
                            })
                        }
                        Button {
                            session.addTab(urlString: nil)
                            session.showTabs = false
                        } label: {
                            Label("Thẻ mới", systemImage: "plus")
                        }
                        .buttonStyle(BrandButtonStyle())
                        .padding(.top, 6)
                    }
                    .padding(16)
                }
            }
            .navigationTitle("Thẻ đang mở (\(session.tabs.count))")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Xong") { session.showTabs = false }
                }
            }
        }
        .presentationDetents([.medium, .large])
    }

    private var linksSheet: some View {
        let links = store.profile(id: session.profile.id)?.links ?? []
        return NavigationStack {
            ZStack {
                Theme.background.ignoresSafeArea()
                ScrollView {
                    VStack(spacing: 10) {
                        if links.isEmpty {
                            Text("Chưa có link nào. Bấm \"Thêm link hiện tại\" trong menu trình duyệt.")
                                .font(.system(size: 13))
                                .foregroundStyle(Theme.secondary)
                                .card(padding: 24)
                        } else {
                            ForEach(links) { link in
                                HStack {
                                    Button {
                                        session.navigate(link.url)
                                        session.showLinks = false
                                    } label: {
                                        VStack(alignment: .leading, spacing: 3) {
                                            Text(link.title)
                                                .font(.system(size: 14, weight: .semibold))
                                                .foregroundStyle(Theme.ink)
                                                .lineLimit(1)
                                            Text(link.url)
                                                .font(.system(size: 11))
                                                .foregroundStyle(Theme.faint)
                                                .lineLimit(1)
                                        }
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                    }
                                    .buttonStyle(.plain)
                                    Button {
                                        removeLink(link)
                                    } label: {
                                        Image(systemName: "trash")
                                            .font(.system(size: 13))
                                            .foregroundStyle(Theme.danger)
                                    }
                                }
                                .card(padding: 14)
                            }
                        }
                        Button {
                            session.addCurrentLink()
                        } label: {
                            Label("Thêm link hiện tại", systemImage: "plus")
                        }
                        .buttonStyle(BrandButtonStyle())
                        .padding(.top, 6)
                    }
                    .padding(16)
                }
            }
            .navigationTitle("Danh sách link · bấm để mở ngay")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Xong") { session.showLinks = false }
                }
            }
        }
        .presentationDetents([.medium, .large])
    }

    private func removeLink(_ link: SavedLink) {
        guard var updated = store.profile(id: session.profile.id) else { return }
        updated.links.removeAll { $0.id == link.id }
        store.upsert(updated)
    }
}

private struct TabRow: View {
    @ObservedObject var tab: BrowserTab
    let active: Bool
    let onOpen: () -> Void
    let onClose: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            Button(action: onOpen) {
                HStack(spacing: 12) {
                    Image(systemName: tab.desktop ? "desktopcomputer" : "globe")
                        .font(.system(size: 16))
                        .foregroundStyle(active ? Theme.brand : Theme.faint)
                    VStack(alignment: .leading, spacing: 3) {
                        Text(tab.displayTitle)
                            .font(.system(size: 14, weight: active ? .semibold : .regular))
                            .foregroundStyle(Theme.ink)
                            .lineLimit(1)
                        Text(tab.url)
                            .font(.system(size: 11))
                            .foregroundStyle(Theme.faint)
                            .lineLimit(1)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    if active {
                        Circle().fill(Theme.brand).frame(width: 8, height: 8)
                    }
                }
            }
            .buttonStyle(.plain)
            Button(action: onClose) {
                Image(systemName: "xmark.circle.fill")
                    .font(.system(size: 18))
                    .foregroundStyle(Theme.faint)
            }
        }
        .card(padding: 14)
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(active ? Theme.brand.opacity(0.5) : Color.clear, lineWidth: 2)
        )
    }
}

struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }

    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}