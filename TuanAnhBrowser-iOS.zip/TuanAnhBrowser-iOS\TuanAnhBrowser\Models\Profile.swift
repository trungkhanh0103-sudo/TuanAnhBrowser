import Foundation

enum ProxyKind: String, Codable, CaseIterable, Identifiable {
    case direct
    case http
    case socks5

    var id: String { rawValue }

    var label: String {
        switch self {
        case .direct: return "Trực tiếp"
        case .http: return "HTTP"
        case .socks5: return "SOCKS5"
        }
    }
}

enum UAMode: String, Codable, CaseIterable, Identifiable {
    case auto
    case real
    case custom

    var id: String { rawValue }

    var label: String {
        switch self {
        case .auto: return "UA tự động"
        case .real: return "UA thật của WebView"
        case .custom: return "UA tùy chỉnh"
        }
    }

    var detail: String {
        switch self {
        case .auto: return "UA, UUID và fingerprint (màn hình, RAM, nhân, cảm ứng...) sẽ đồng bộ theo thiết bị."
        case .real: return "UA thật của WebView · không giả thiết bị · UUID mới"
        case .custom: return "UA tự nhập · fingerprint theo UA"
        }
    }
}

enum RTCMode: String, Codable, CaseIterable, Identifiable {
    case relay
    case off

    var id: String { rawValue }

    var label: String {
        switch self {
        case .relay: return "Relay · không lộ IP"
        case .off: return "Tắt hẳn"
        }
    }
}

struct SavedLink: Codable, Identifiable, Equatable {
    var id = UUID()
    var title: String
    var url: String
}

struct Profile: Codable, Identifiable, Equatable {
    var uuid = UUID()
    var name: String
    var home: String
    var lang: String
    var device: Int
    var deviceName: String
    var uaMode: UAMode
    var customUa: String
    var spoofUa: Bool
    var platform: String
    var sw: Int
    var sh: Int
    var dpr: Double
    var touch: Int
    var cores: Int
    var mem: Int
    var gpuV: String
    var gpuR: String
    var seed: Int
    var proxyType: ProxyKind
    var proxyHost: String
    var proxyPort: Int
    var proxyUser: String
    var proxyPass: String
    var tz: String
    var rtc: RTCMode
    var blockImg: Bool
    var color: Int
    var note: String
    var links: [SavedLink]
    var tabs: [String]
    var createdAt: Double
    var lastUsed: Double

    var id: UUID { uuid }

    var hasProxy: Bool { proxyType != .direct && !proxyHost.isEmpty && proxyPort > 0 }

    var proxySummary: String {
        guard hasProxy else { return "Kết nối trực tiếp · không ẩn IP" }
        return "\(proxyType.label) · \(proxyHost):\(proxyPort)"
    }

    var effectiveUA: String {
        switch uaMode {
        case .auto:
            return Devices.template(at: device).ua
        case .custom:
            let trimmed = customUa.trimmingCharacters(in: .whitespacesAndNewlines)
            return trimmed.isEmpty ? Devices.template(at: device).ua : trimmed
        case .real:
            return ""
        }
    }

    var spoofEnabled: Bool { uaMode != .real && spoofUa }

    static func new(index: Int) -> Profile {
        let template = Devices.template(at: index)
        let now = Date().timeIntervalSince1970
        return Profile(
            name: "Hồ sơ mới",
            home: "https://www.google.com",
            lang: "vi-VN",
            device: index,
            deviceName: template.name,
            uaMode: .auto,
            customUa: "",
            spoofUa: true,
            platform: template.platform,
            sw: template.sw,
            sh: template.sh,
            dpr: template.dpr,
            touch: template.touch,
            cores: template.cores,
            mem: template.mem,
            gpuV: template.gpuV,
            gpuR: template.gpuR,
            seed: Int.random(in: 1...Int(Int32.max)),
            proxyType: .direct,
            proxyHost: "",
            proxyPort: 0,
            proxyUser: "",
            proxyPass: "",
            tz: "",
            rtc: .relay,
            blockImg: false,
            color: Int.random(in: 0..<Profile.avatarColors.count),
            note: "",
            links: [],
            tabs: [],
            createdAt: now,
            lastUsed: now
        )
    }

    mutating func applyDevice(_ index: Int) {
        let template = Devices.template(at: index)
        device = index
        deviceName = template.name
        platform = template.platform
        sw = template.sw
        sh = template.sh
        dpr = template.dpr
        touch = template.touch
        cores = template.cores
        mem = template.mem
        gpuV = template.gpuV
        gpuR = template.gpuR
        seed = Int.random(in: 1...Int(Int32.max))
        uuid = UUID()
    }

    static let avatarColors: [(String, String)] = [
        ("#4F46E5", "#3D5AFE"),
        ("#0EA5E9", "#2563EB"),
        ("#8B5CF6", "#6366F1"),
        ("#EC4899", "#8B5CF6"),
        ("#F59E0B", "#EF4444"),
        ("#10B981", "#0EA5E9"),
        ("#F97316", "#F59E0B"),
        ("#14B8A6", "#10B981")
    ]
}

struct ParsedProxy {
    let kind: ProxyKind
    let host: String
    let port: Int
    let user: String
    let pass: String

    init?(_ profile: Profile) {
        guard profile.hasProxy else { return nil }
        kind = profile.proxyType
        host = profile.proxyHost
        port = profile.proxyPort
        user = profile.proxyUser
        pass = profile.proxyPass
    }

    init?(text: String, kind: ProxyKind) {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty, kind != .direct else { return nil }
        var rest = trimmed
        var user = ""
        var pass = ""
        if let at = rest.lastIndex(of: "@") {
            let auth = String(rest[..<at])
            rest = String(rest[rest.index(after: at)...])
            if let colon = auth.firstIndex(of: ":") {
                user = String(auth[..<colon])
                pass = String(auth[auth.index(after: colon)...])
            } else {
                user = auth
            }
        }
        guard let colon = rest.lastIndex(of: ":"),
              let port = Int(rest[rest.index(after: colon)...]), port > 0, port <= 65535 else { return nil }
        let host = String(rest[..<colon])
        guard !host.isEmpty else { return nil }
        self.kind = kind
        self.host = host
        self.port = port
        self.user = user
        self.pass = pass
    }
}