import Foundation
import WebKit
import Network

@MainActor
final class BrowserEngine {
    let profile: Profile
    let runtimeTz: String
    let dataStore: WKWebsiteDataStore
    let processPool = WKProcessPool()
    private var imageBlockRules: WKContentRuleList?

    private static let injectTemplate: String = {
        guard let url = Bundle.main.url(forResource: "inject", withExtension: "js"),
              let source = try? String(contentsOf: url, encoding: .utf8) else {
            return ""
        }
        return source
    }()

    init(profile: Profile, runtimeTz: String) {
        self.profile = profile
        self.runtimeTz = runtimeTz
        dataStore = WKWebsiteDataStore(forIdentifier: profile.uuid)
        applyProxy()
        if profile.blockImg {
            compileImageBlockRules()
        }
    }

    private func applyProxy() {
        guard let proxy = ParsedProxy(profile), let port = UInt16(exactly: proxy.port) else {
            dataStore.proxyConfigurations = []
            return
        }
        let endpoint = NWEndpoint.hostPort(host: NWEndpoint.Host(proxy.host), port: NWEndpoint.Port(integerLiteral: port))
        let config: ProxyConfiguration
        switch proxy.kind {
        case .http:
            config = ProxyConfiguration(httpCONNECTProxy: endpoint, tlsOptions: nil)
            if !proxy.user.isEmpty {
                config.applyCredential(username: proxy.user, password: proxy.pass)
            }
        case .socks5:
            config = ProxyConfiguration(socksv5Proxy: endpoint)
        case .direct:
            dataStore.proxyConfigurations = []
            return
        }
        config.allowFailover = false
        dataStore.proxyConfigurations = [config]
    }

    private func compileImageBlockRules() {
        let json = """
        [{"trigger":{"url-filter":".*","resource-type":["image"]},"action":{"type":"block"}}]
        """
        WKContentRuleListStore.default().compileContentRuleList(forIdentifier: "blockImages", encodedContentRuleList: json) { [weak self] list, _ in
            Task { @MainActor in
                self?.imageBlockRules = list
            }
        }
    }

    private func injectConfig(desktop: Bool) -> [String: Any] {
        let ua: String
        let platform: String
        let sw: Int, sh: Int, dpr: Double, touch: Int, cores: Int, mem: Int
        let gpuV: String, gpuR: String

        if desktop {
            let win = Devices.windows
            ua = win.ua
            platform = win.platform
            sw = win.sw; sh = win.sh; dpr = win.dpr
            touch = win.touch; cores = win.cores; mem = win.mem
            gpuV = win.gpuV; gpuR = win.gpuR
        } else {
            ua = profile.effectiveUA
            platform = profile.platform
            sw = profile.sw; sh = profile.sh; dpr = profile.dpr
            touch = profile.touch; cores = profile.cores; mem = profile.mem
            gpuV = profile.gpuV; gpuR = profile.gpuR
        }

        let spoof = desktop ? true : profile.spoofEnabled
        return [
            "spoofUa": spoof,
            "ua": ua,
            "platform": platform,
            "touch": touch,
            "cores": cores,
            "lang": profile.lang,
            "mem": mem,
            "sw": sw,
            "sh": sh,
            "dpr": dpr,
            "gpuV": gpuV,
            "gpuR": gpuR,
            "seed": profile.seed,
            "tz": runtimeTz,
            "rtc": profile.rtc.rawValue
        ]
    }

    private func injectScript(desktop: Bool) -> String {
        let config = injectConfig(desktop: desktop)
        guard let data = try? JSONSerialization.data(withJSONObject: config, options: [.sortedKeys]),
              let json = String(data: data, encoding: .utf8) else {
            return Self.injectTemplate.replacingOccurrences(of: "__CFG__", with: "{}")
        }
        return Self.injectTemplate.replacingOccurrences(of: "__CFG__", with: json)
    }

    func makeWebView(desktop: Bool, baseConfiguration: WKWebViewConfiguration? = nil) -> WKWebView {
        let config = baseConfiguration ?? WKWebViewConfiguration()
        config.websiteDataStore = dataStore
        config.processPool = processPool
        config.defaultWebpagePreferences.allowsContentJavaScript = true
        config.preferences.javaScriptCanOpenWindowsAutomatically = true
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.allowsPictureInPictureMediaPlayback = true

        let controller = WKUserContentController()
        controller.addUserScript(
            WKUserScript(source: injectScript(desktop: desktop), injectionTime: .atDocumentStart, forMainFrameOnly: false)
        )
        if profile.blockImg, let rules = imageBlockRules {
            controller.add(rules)
        }
        config.userContentController = controller

        let webView = WKWebView(frame: .zero, configuration: config)
        if desktop {
            webView.customUserAgent = Devices.windows.ua
        } else if profile.spoofEnabled {
            webView.customUserAgent = profile.effectiveUA
        }
        webView.allowsBackForwardNavigationGestures = true
        webView.scrollView.keyboardDismissMode = .onDrag
        return webView
    }

    // MARK: - Branded error page (same design as Android)

    static func errorPage(failedURL: String, message: String) -> String {
        let escapedURL = htmlEscape(failedURL)
        let escapedMessage = htmlEscape(message)
        return """
        <!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><style>body{margin:0;font-family:-apple-system,'Segoe UI',Roboto,sans-serif;background:#EDF0F9;color:#141B38;display:flex;align-items:center;justify-content:center;min-height:100vh;padding:24px;box-sizing:border-box}.card{background:#fff;border-radius:24px;padding:36px 28px;max-width:340px;text-align:center;box-shadow:0 12px 40px rgba(20,27,56,.10)}h1{font-size:19px;margin:18px 0 8px}p{font-size:13px;color:#66708C;line-height:1.6;margin:6px 0}.btn{display:inline-block;margin-top:20px;padding:12px 28px;border-radius:22px;color:#fff;text-decoration:none;font-weight:600;font-size:14px;background:linear-gradient(135deg,#4F46E5,#3D5AFE)}.foot{margin-top:18px;font-size:11px;color:#98A2CB;letter-spacing:.06em}</style></head><body><div class='card'><svg width='72' height='72' viewBox='0 0 72 72'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='#4F46E5'/><stop offset='1' stop-color='#00C2FF'/></linearGradient></defs><circle cx='36' cy='36' r='34' fill='url(#g)' opacity='.14'/><circle cx='36' cy='36' r='24' fill='url(#g)'/><path d='M36 22l-9 4v6c0 5.6 3.8 10.8 9 12 5.2-1.2 9-6.4 9-12v-6l-9-4zm-1.8 18.2l-4-4 1.9-1.9 2.1 2.1 5.7-5.7 1.9 1.9-7.6 7.6z' fill='#fff'/></svg><h1>Không thể mở trang</h1><p>\(escapedMessage)</p><p>Kiểm tra lại proxy hoặc kết nối mạng của hồ sơ này.</p><a class='btn' href="\(escapedURL)">Thử lại</a><div class='foot'>TUANANH BROWSER · ẨN DANH</div></div></body></html>
        """
    }

    private static func htmlEscape(_ text: String) -> String {
        text.replacingOccurrences(of: "&", with: "&amp;")
            .replacingOccurrences(of: "<", with: "&lt;")
            .replacingOccurrences(of: ">", with: "&gt;")
            .replacingOccurrences(of: "\"", with: "&quot;")
            .replacingOccurrences(of: "'", with: "&#39;")
    }
}