import Foundation
import CFNetwork
import Network

struct ProxyInfo {
    var ip: String = ""
    var country: String = ""
    var countryCode: String = ""
    var timezone: String = ""
    var isp: String = ""
    var isMobile = false
    var isProxy = false
    var isHosting = false
    var latencyMs: Double?
    var error: String?

    var flag: String {
        guard countryCode.count == 2 else { return "" }
        let base: UInt32 = 127397
        var scalar = String.UnicodeScalarView()
        for letter in countryCode.uppercased().unicodeScalars {
            if let flagScalar = Unicode.Scalar(base + letter.value) {
                scalar.append(flagScalar)
            }
        }
        return String(scalar)
    }
}

private final class ProxyAuthDelegate: NSObject, URLSessionTaskDelegate {
    let user: String
    let pass: String

    init(user: String, pass: String) {
        self.user = user
        self.pass = pass
    }

    func urlSession(_ session: URLSession, task: URLSessionTask,
                    didReceive challenge: URLAuthenticationChallenge,
                    completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        let type = challenge.protectionSpace.proxyType
        if (type == NSURLProtectionSpaceHTTPProxy || type == NSURLProtectionSpaceHTTPSProxy), !user.isEmpty {
            completionHandler(.useCredential, URLCredential(user: user, password: pass, persistence: .forSession))
        } else {
            completionHandler(.performDefaultHandling, nil)
        }
    }
}

@MainActor
final class ProxyCheck: ObservableObject {
    @Published var checking = false
    @Published var info: ProxyInfo?

    static func proxyDictionary(_ proxy: ParsedProxy?) -> [AnyHashable: Any] {
        guard let proxy else { return [:] }
        var dict: [AnyHashable: Any] = [:]
        switch proxy.kind {
        case .direct:
            break
        case .http:
            dict[kCFNetworkProxiesHTTPEnable] = 1
            dict[kCFNetworkProxiesHTTPProxy] = proxy.host
            dict[kCFNetworkProxiesHTTPPort] = proxy.port
            dict[kCFNetworkProxiesHTTPSEnable] = 1
            dict[kCFNetworkProxiesHTTPSProxy] = proxy.host
            dict[kCFNetworkProxiesHTTPSPort] = proxy.port
        case .socks5:
            dict[kCFNetworkProxiesSOCKSEnable] = 1
            dict[kCFNetworkProxiesSOCKSProxy] = proxy.host
            dict[kCFNetworkProxiesSOCKSPort] = proxy.port
        }
        return dict
    }

    func check(_ proxy: ParsedProxy?) async -> ProxyInfo {
        checking = true
        defer { checking = false }
        let start = Date()
        var result = await fetchIPAPI(proxy)
        if result.error != nil {
            result = await fetchIPWho(proxy)
        }
        if result.error == nil {
            result.latencyMs = Date().timeIntervalSince(start) * 1000
        }
        info = result
        return result
    }

    private func makeSession(_ proxy: ParsedProxy?) -> URLSession {
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 12
        config.timeoutIntervalForResource = 20
        let dict = Self.proxyDictionary(proxy)
        if !dict.isEmpty {
            config.connectionProxyDictionary = dict
        }
        if let proxy, proxy.kind == .http, !proxy.user.isEmpty {
            let delegate = ProxyAuthDelegate(user: proxy.user, pass: proxy.pass)
            return URLSession(configuration: config, delegate: delegate, delegateQueue: nil)
        }
        return URLSession(configuration: config)
    }

    private func fetchIPAPI(_ proxy: ParsedProxy?) async -> ProxyInfo {
        var result = ProxyInfo()
        let url = URL(string: "http://ip-api.com/json/?fields=status,message,country,countryCode,timezone,isp,mobile,proxy,hosting,query")!
        let session = makeSession(proxy)
        defer { session.finishTasksAndInvalidate() }
        do {
            let (data, response) = try await session.data(from: url)
            if let http = response as? HTTPURLResponse, http.statusCode == 407 {
                result.error = "Proxy yêu cầu đăng nhập (407) — sai user:pass"
                return result
            }
            guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                result.error = "Không đọc được phản hồi IP"
                return result
            }
            guard (json["status"] as? String) == "success" else {
                result.error = "Không tra được IP"
                return result
            }
            result.ip = json["query"] as? String ?? ""
            result.country = json["country"] as? String ?? ""
            result.countryCode = json["countryCode"] as? String ?? ""
            result.timezone = json["timezone"] as? String ?? ""
            result.isp = json["isp"] as? String ?? ""
            result.isMobile = json["mobile"] as? Bool ?? false
            result.isProxy = json["proxy"] as? Bool ?? false
            result.isHosting = json["hosting"] as? Bool ?? false
        } catch {
            result.error = mapError(error)
        }
        return result
    }

    private func fetchIPWho(_ proxy: ParsedProxy?) async -> ProxyInfo {
        var result = ProxyInfo()
        let url = URL(string: "https://ipwho.is/")!
        let session = makeSession(proxy)
        defer { session.finishTasksAndInvalidate() }
        do {
            let (data, _) = try await session.data(from: url)
            guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                  (json["success"] as? Bool) == true else {
                result.error = "Không tra được IP (mạng yếu hoặc máy chủ chặn)."
                return result
            }
            result.ip = json["ip"] as? String ?? ""
            result.country = json["country"] as? String ?? ""
            result.countryCode = json["country_code"] as? String ?? ""
            if let tz = json["timezone"] as? [String: Any] {
                result.timezone = tz["id"] as? String ?? ""
            }
            if let connection = json["connection"] as? [String: Any] {
                result.isp = connection["isp"] as? String ?? ""
            }
        } catch {
            result.error = mapError(error)
        }
        return result
    }

    private func mapError(_ error: Error) -> String {
        let ns = error as NSError
        if ns.domain == NSURLErrorDomain {
            switch ns.code {
            case NSURLErrorTimedOut:
                return "Không kết nối được (mạng yếu hoặc máy chủ chặn)."
            case NSURLErrorCannotConnectToHost, NSURLErrorNetworkConnectionLost:
                return "Proxy lỗi: không kết nối được máy chủ proxy."
            default:
                break
            }
        }
        return "Lỗi: \(ns.localizedDescription)"
    }

    // MARK: - TCP ping (direct from device, not through the webview proxy)

    nonisolated static func ping(host: String, port: UInt16, timeout: TimeInterval = 5) async -> Double? {
        await withCheckedContinuation { continuation in
            let connection = NWConnection(
                host: NWEndpoint.Host(host),
                port: NWEndpoint.Port(integerLiteral: port),
                using: .tcp
            )
            let queue = DispatchQueue(label: "tcpping")
            let start = DispatchTime.now()
            var resumed = false
            let finish: (Double?) -> Void = { value in
                queue.async {
                    guard !resumed else { return }
                    resumed = true
                    connection.cancel()
                    continuation.resume(returning: value)
                }
            }
            connection.stateUpdateHandler = { state in
                switch state {
                case .ready:
                    let elapsed = Double(DispatchTime.now().uptimeNanoseconds - start.uptimeNanoseconds) / 1_000_000
                    finish(elapsed)
                case .failed, .cancelled:
                    finish(nil)
                default:
                    break
                }
            }
            connection.start(queue: queue)
            queue.asyncAfter(deadline: .now() + timeout) { finish(nil) }
        }
    }
}