import Foundation
import WebKit
import SwiftUI
import UIKit

@MainActor
final class BrowserTab: ObservableObject, Identifiable {
    let id = UUID()
    let webView: WKWebView
    let desktop: Bool
    @Published var url: String = ""
    @Published var title: String = ""
    @Published var isLoading = false
    @Published var progress: Double = 0
    @Published var canGoBack = false
    @Published var canGoForward = false

    fileprivate var coordinator: TabCoordinator?
    private var observations: [NSKeyValueObservation] = []

    init(webView: WKWebView, desktop: Bool) {
        self.webView = webView
        self.desktop = desktop
        observations = [
            webView.observe(\.url, options: [.new]) { [weak self] webView, _ in
                Task { @MainActor in self?.url = webView.url?.absoluteString ?? "" }
            },
            webView.observe(\.title, options: [.new]) { [weak self] webView, _ in
                Task { @MainActor in self?.title = webView.title ?? "" }
            },
            webView.observe(\.isLoading, options: [.new]) { [weak self] webView, _ in
                Task { @MainActor in self?.isLoading = webView.isLoading }
            },
            webView.observe(\.estimatedProgress, options: [.new]) { [weak self] webView, _ in
                Task { @MainActor in self?.progress = webView.estimatedProgress }
            },
            webView.observe(\.canGoBack, options: [.new]) { [weak self] webView, _ in
                Task { @MainActor in self?.canGoBack = webView.canGoBack }
            },
            webView.observe(\.canGoForward, options: [.new]) { [weak self] webView, _ in
                Task { @MainActor in self?.canGoForward = webView.canGoForward }
            }
        ]
    }

    var displayTitle: String {
        if !title.isEmpty { return title }
        if let host = URL(string: url)?.host { return host }
        return "Thẻ mới"
    }
}

@MainActor
final class BrowserSession: ObservableObject {
    let profile: Profile
    let engine: BrowserEngine
    let store: ProfileStore

    @Published var tabs: [BrowserTab] = []
    @Published var activeTabID: UUID?
    @Published var addressText = ""
    @Published var showTabs = false
    @Published var showLinks = false
    @Published var alertMessage: String?
    @Published var savedDownload: URL?

    private var activeDownloads: [WKDownload] = []

    init(profile: Profile, runtimeTz: String, store: ProfileStore) {
        self.profile = profile
        self.store = store
        engine = BrowserEngine(profile: profile, runtimeTz: runtimeTz)
        let restored = profile.tabs.filter { !$0.isEmpty }
        if restored.isEmpty {
            addTab(urlString: profile.home)
        } else {
            for url in restored { addTab(urlString: url) }
        }
        activeTabID = tabs.first?.id
        syncAddress()
    }

    var activeTab: BrowserTab? {
        tabs.first { $0.id == activeTabID }
    }

    var hasProxy: Bool { profile.hasProxy }

    // MARK: - Tabs

    @discardableResult
    func addTab(urlString: String?, activate: Bool = true, load: Bool = true,
                desktop: Bool = false, baseConfiguration: WKWebViewConfiguration? = nil) -> BrowserTab {
        let webView = engine.makeWebView(desktop: desktop, baseConfiguration: baseConfiguration)
        let tab = BrowserTab(webView: webView, desktop: desktop)
        let coordinator = TabCoordinator(session: self, tab: tab)
        tab.coordinator = coordinator
        webView.navigationDelegate = coordinator
        webView.uiDelegate = coordinator
        tabs.append(tab)
        if activate {
            activeTabID = tab.id
            syncAddress()
        }
        if load, let url = Self.normalize(urlString ?? profile.home) {
            webView.load(URLRequest(url: url))
        }
        return tab
    }

    func closeTab(_ id: UUID) {
        guard let index = tabs.firstIndex(where: { $0.id == id }) else { return }
        tabs[index].webView.stopLoading()
        tabs.remove(at: index)
        if tabs.isEmpty {
            addTab(urlString: profile.home)
        } else if activeTabID == id {
            activeTabID = tabs[min(index, tabs.count - 1)].id
        }
        syncAddress()
        persistTabs()
    }

    func activate(_ id: UUID) {
        activeTabID = id
        syncAddress()
    }

    func toggleDesktop() {
        guard let tab = activeTab, let index = tabs.firstIndex(where: { $0.id == tab.id }) else { return }
        let currentURL = tab.webView.url?.absoluteString ?? tab.url
        let desktop = !tab.desktop
        let webView = engine.makeWebView(desktop: desktop)
        let newTab = BrowserTab(webView: webView, desktop: desktop)
        let coordinator = TabCoordinator(session: self, tab: newTab)
        newTab.coordinator = coordinator
        webView.navigationDelegate = coordinator
        webView.uiDelegate = coordinator
        tab.webView.stopLoading()
        tabs[index] = newTab
        activeTabID = newTab.id
        if let url = URL(string: currentURL), url.scheme?.hasPrefix("http") == true {
            webView.load(URLRequest(url: url))
        }
        syncAddress()
    }

    // MARK: - Navigation

    func navigate(_ text: String) {
        guard let tab = activeTab, let url = Self.normalize(text) else { return }
        tab.webView.load(URLRequest(url: url))
        addressText = url.absoluteString
    }

    func goBack() { activeTab?.webView.goBack() }
    func goForward() { activeTab?.webView.goForward() }
    func reload() { activeTab?.webView.reload() }
    func stopLoading() { activeTab?.webView.stopLoading() }
    func goHome() { navigate(profile.home) }

    func syncAddress() {
        addressText = activeTab?.url ?? ""
    }

    func tabDidFinish(_ tab: BrowserTab) {
        if tab.id == activeTabID { syncAddress() }
        persistTabs()
    }

    func persistTabs() {
        var updated = store.profile(id: profile.id) ?? profile
        updated.tabs = tabs.compactMap { $0.url.isEmpty ? nil : $0.url }
        store.upsert(updated)
    }

    static func normalize(_ text: String) -> URL? {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }
        if trimmed.hasPrefix("http://") || trimmed.hasPrefix("https://") {
            return URL(string: trimmed) ?? URL(string: trimmed.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")
        }
        if trimmed.contains(" ") || !trimmed.contains(".") {
            let query = trimmed.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
            return URL(string: "https://www.google.com/search?q=" + query)
        }
        return URL(string: "https://" + trimmed)
    }

    // MARK: - Links

    func addCurrentLink() {
        guard let tab = activeTab, !tab.url.isEmpty, tab.url.hasPrefix("http") else { return }
        var updated = store.profile(id: profile.id) ?? profile
        guard !updated.links.contains(where: { $0.url == tab.url }) else { return }
        updated.links.append(SavedLink(title: tab.displayTitle, url: tab.url))
        store.upsert(updated)
        alertMessage = "Đã thêm vào danh sách link"
    }

    // MARK: - Downloads

    func beginDownload(_ download: WKDownload, coordinator: TabCoordinator) {
        activeDownloads.append(download)
        download.delegate = coordinator
    }

    func completeDownload(at url: URL, download: WKDownload) {
        activeDownloads.removeAll { $0 === download }
        savedDownload = url
    }

    func failDownload(_ download: WKDownload, error: Error) {
        activeDownloads.removeAll { $0 === download }
        alertMessage = "Lỗi tải: \(error.localizedDescription)"
    }

    func blockDownload() {
        alertMessage = "Tải file bị chặn khi dùng proxy (tránh lộ IP thật)"
    }

    static var downloadsDirectory: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let dir = docs.appendingPathComponent("Downloads", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }
}

// MARK: - Per-tab delegate

@MainActor
final class TabCoordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKDownloadDelegate {
    private weak var session: BrowserSession?
    private weak var tab: BrowserTab?
    private var downloadDestination: URL?

    init(session: BrowserSession, tab: BrowserTab) {
        self.session = session
        self.tab = tab
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else {
            decisionHandler(.cancel)
            return
        }
        let scheme = url.scheme?.lowercased() ?? ""
        if scheme == "http" || scheme == "https" || scheme == "about" || scheme == "file" || scheme == "blob" || scheme == "data" {
            if navigationAction.shouldPerformDownload {
                if session?.hasProxy == true {
                    session?.blockDownload()
                    decisionHandler(.cancel)
                } else {
                    decisionHandler(.allow)
                }
                return
            }
            decisionHandler(.allow)
            return
        }
        UIApplication.shared.open(url)
        decisionHandler(.cancel)
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse,
                 decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        if navigationResponse.canShowMIMEType {
            decisionHandler(.allow)
            return
        }
        if session?.hasProxy == true {
            session?.blockDownload()
            decisionHandler(.cancel)
            return
        }
        decisionHandler(.download)
    }

    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        if let url = webView.url?.absoluteString {
            tab?.url = url
            if tab?.id == session?.activeTabID { session?.addressText = url }
        }
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        tab?.url = webView.url?.absoluteString ?? ""
        tab?.title = webView.title ?? ""
        if let tab { session?.tabDidFinish(tab) }
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        showErrorPage(webView, error: error)
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        showErrorPage(webView, error: error)
    }

    private func showErrorPage(_ webView: WKWebView, error: Error) {
        let ns = error as NSError
        if ns.domain == NSURLErrorDomain && ns.code == NSURLErrorCancelled { return }
        let failedURL = (ns.userInfo[NSURLErrorFailingURLStringErrorKey] as? String) ?? tab?.url ?? ""
        guard failedURL.hasPrefix("http") else { return }
        webView.loadHTMLString(BrowserEngine.errorPage(failedURL: failedURL, message: ns.localizedDescription), baseURL: nil)
    }

    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) {
        if let tab { session?.beginDownload(download, coordinator: tab.coordinator ?? self) }
    }

    func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) {
        if let tab { session?.beginDownload(download, coordinator: tab.coordinator ?? self) }
    }

    // MARK: WKUIDelegate

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        guard let session else { return nil }
        let newTab = session.addTab(urlString: navigationAction.request.url?.absoluteString, activate: true, load: false,
                                    desktop: tab?.desktop ?? false, baseConfiguration: configuration)
        return newTab.webView
    }

    func webViewDidClose(_ webView: WKWebView) {
        if let tab { session?.closeTab(tab.id) }
    }

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
        Self.present(alert)
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Hủy", style: .cancel) { _ in completionHandler(false) })
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(true) })
        Self.present(alert)
    }

    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String,
                 defaultText: String?, initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping (String?) -> Void) {
        let alert = UIAlertController(title: nil, message: prompt, preferredStyle: .alert)
        alert.addTextField { $0.text = defaultText }
        alert.addAction(UIAlertAction(title: "Hủy", style: .cancel) { _ in completionHandler(nil) })
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(alert.textFields?.first?.text) })
        Self.present(alert)
    }

    private static func present(_ alert: UIAlertController) {
        guard let scene = UIApplication.shared.connectedScenes.first(where: { $0.activationState == .foregroundActive }) as? UIWindowScene,
              let root = scene.keyWindow?.rootViewController else { return }
        var top = root
        while let presented = top.presentedViewController { top = presented }
        top.present(alert, animated: true)
    }

    // MARK: WKDownloadDelegate

    nonisolated func download(_ download: WKDownload, decideDestinationUsing response: URLResponse,
                              suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
        Task { @MainActor in
            let dir = BrowserSession.downloadsDirectory
            var url = dir.appendingPathComponent(suggestedFilename)
            var counter = 1
            while FileManager.default.fileExists(atPath: url.path) {
                let base = (suggestedFilename as NSString).deletingPathExtension
                let ext = (suggestedFilename as NSString).pathExtension
                let name = ext.isEmpty ? "\(base)-\(counter)" : "\(base)-\(counter).\(ext)"
                url = dir.appendingPathComponent(name)
                counter += 1
            }
            self.downloadDestination = url
            completionHandler(url)
        }
    }

    nonisolated func downloadDidFinish(_ download: WKDownload) {
        Task { @MainActor in
            if let url = self.downloadDestination {
                self.session?.completeDownload(at: url, download: download)
            }
            self.downloadDestination = nil
        }
    }

    nonisolated func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) {
        Task { @MainActor in
            self.session?.failDownload(download, error: error)
            self.downloadDestination = nil
        }
    }
}