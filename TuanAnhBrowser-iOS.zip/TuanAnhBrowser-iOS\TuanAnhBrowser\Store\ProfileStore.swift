import Foundation
import SwiftUI
import WebKit

@MainActor
final class ProfileStore: ObservableObject {
    @Published var profiles: [Profile] = [] {
        didSet { save() }
    }

    private let fileURL: URL

    init() {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        fileURL = docs.appendingPathComponent("profiles.json")
        load()
    }

    private func load() {
        guard let data = try? Data(contentsOf: fileURL) else { return }
        let decoder = JSONDecoder()
        if let list = try? decoder.decode([Profile].self, from: data) {
            profiles = list
        } else if let backup = try? decoder.decode(BackupFile.self, from: data) {
            profiles = backup.profiles
        }
    }

    private func save() {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        guard let data = try? encoder.encode(profiles) else { return }
        try? data.write(to: fileURL, options: [.atomic])
    }

    func profile(id: UUID) -> Profile? {
        profiles.first { $0.id == id }
    }

    func upsert(_ profile: Profile) {
        if let index = profiles.firstIndex(where: { $0.id == profile.id }) {
            profiles[index] = profile
        } else {
            profiles.append(profile)
        }
    }

    func touch(_ id: UUID) {
        guard let index = profiles.firstIndex(where: { $0.id == id }) else { return }
        profiles[index].lastUsed = Date().timeIntervalSince1970
    }

    func delete(_ profile: Profile) {
        wipeData(uuid: profile.uuid)
        profiles.removeAll { $0.id == profile.id }
    }

    func wipeData(uuid: UUID) {
        let store = WKWebsiteDataStore(forIdentifier: uuid)
        store.removeData(ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(), modifiedSince: Date.distantPast) {}
    }

    func clearCookies(_ profile: Profile) {
        let store = WKWebsiteDataStore(forIdentifier: profile.uuid)
        let types: Set<String> = [
            WKWebsiteDataTypeCookies,
            WKWebsiteDataTypeLocalStorage,
            WKWebsiteDataTypeSessionStorage,
            WKWebsiteDataTypeIndexedDBDatabases,
            WKWebsiteDataTypeWebSQLDatabases
        ]
        store.removeData(ofTypes: types, modifiedSince: Date.distantPast) {}
    }

    func clearCache(_ profile: Profile) {
        let store = WKWebsiteDataStore(forIdentifier: profile.uuid)
        let types: Set<String> = [WKWebsiteDataTypeDiskCache, WKWebsiteDataTypeMemoryCache]
        store.removeData(ofTypes: types, modifiedSince: Date.distantPast) {}
    }

    // MARK: - Backup

    struct BackupFile: Codable {
        var version: Int
        var exportedAt: Double
        var profiles: [Profile]
    }

    func exportData() throws -> Data {
        let backup = BackupFile(version: 2, exportedAt: Date().timeIntervalSince1970, profiles: profiles)
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        return try encoder.encode(backup)
    }

    func importData(_ data: Data) throws -> Int {
        let decoder = JSONDecoder()
        let incoming: [Profile]
        if let backup = try? decoder.decode(BackupFile.self, from: data) {
            incoming = backup.profiles
        } else {
            incoming = try decoder.decode([Profile].self, from: data)
        }
        var added = 0
        for var profile in incoming {
            if profiles.contains(where: { $0.id == profile.id }) {
                profile.uuid = UUID()
            }
            upsert(profile)
            added += 1
        }
        return added
    }
}