import SwiftUI

@main
struct TuanAnhBrowserApp: App {
    @StateObject private var store = ProfileStore()

    var body: some Scene {
        WindowGroup {
            ProfilesView()
                .environmentObject(store)
                .tint(Theme.brand)
        }
    }
}