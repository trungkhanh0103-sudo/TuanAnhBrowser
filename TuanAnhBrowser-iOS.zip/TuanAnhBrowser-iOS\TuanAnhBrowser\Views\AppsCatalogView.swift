import SwiftUI

struct CatalogApp: Codable, Identifiable {
    let name: String
    let url: String
    var id: String { url }

    var domain: String {
        URL(string: url)?.host ?? url
    }
}

enum AppsCatalog {
    static let apps: [CatalogApp] = {
        guard let url = Bundle.main.url(forResource: "apps-catalog", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let list = try? JSONDecoder().decode([CatalogApp].self, from: data) else {
            return []
        }
        return list
    }()
}

struct AppsCatalogView: View {
    let onOpen: (String) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var search = ""

    private var filtered: [CatalogApp] {
        let text = search.trimmingCharacters(in: .whitespaces).lowercased()
        if text.isEmpty { return AppsCatalog.apps }
        return AppsCatalog.apps.filter { $0.name.lowercased().contains(text) || $0.domain.lowercased().contains(text) }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Theme.background.ignoresSafeArea()
                ScrollView {
                    VStack(spacing: 10) {
                        HStack(spacing: 8) {
                            Image(systemName: "magnifyingglass")
                                .font(.system(size: 13))
                                .foregroundStyle(Theme.faint)
                            TextField("Tìm app...", text: $search)
                                .font(.system(size: 14))
                                .autocorrectionDisabled()
                                .textInputAutocapitalization(.never)
                        }
                        .padding(.horizontal, 14)
                        .padding(.vertical, 10)
                        .background(Color.white)
                        .clipShape(Capsule())
                        ForEach(filtered) { app in
                            Button { onOpen(app.url) } label: {
                                HStack(spacing: 12) {
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                                            .fill(Theme.avatarGradient(app.name.count))
                                        Text(String(app.name.prefix(2)))
                                            .font(.system(size: 15, weight: .heavy))
                                            .foregroundStyle(.white)
                                    }
                                    .frame(width: 46, height: 46)
                                    VStack(alignment: .leading, spacing: 3) {
                                        Text(app.name)
                                            .font(.system(size: 15, weight: .semibold))
                                            .foregroundStyle(Theme.ink)
                                        Text(app.domain)
                                            .font(.system(size: 11))
                                            .foregroundStyle(Theme.faint)
                                            .lineLimit(1)
                                    }
                                    Spacer()
                                    Image(systemName: "arrow.up.right.square")
                                        .font(.system(size: 16))
                                        .foregroundStyle(Theme.brand.opacity(0.7))
                                }
                                .card(padding: 12)
                            }
                            .buttonStyle(.plain)
                        }
                        Text("Bấm vào link để mở ngay bằng hồ sơ đang chọn")
                            .font(.system(size: 11))
                            .foregroundStyle(Theme.faint)
                            .padding(.top, 8)
                    }
                    .padding(16)
                }
            }
            .navigationTitle("Tải App")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Đóng") { dismiss() }
                }
            }
        }
    }
}