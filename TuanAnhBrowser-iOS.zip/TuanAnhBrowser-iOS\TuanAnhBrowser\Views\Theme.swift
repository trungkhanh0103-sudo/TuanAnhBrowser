import SwiftUI
import WebKit

enum Theme {
    static let brand = Color(hex: 0x4F46E5)
    static let brand2 = Color(hex: 0x3D5AFE)
    static let accent = Color(hex: 0x00C2FF)
    static let background = Color(hex: 0xEDF0F9)
    static let ink = Color(hex: 0x141B38)
    static let secondary = Color(hex: 0x66708C)
    static let faint = Color(hex: 0x98A2CB)
    static let danger = Color(hex: 0xE5484D)
    static let warning = Color(hex: 0xF59E0B)
    static let ok = Color(hex: 0x10B981)

    static let gradient = LinearGradient(colors: [brand, brand2], startPoint: .topLeading, endPoint: .bottomTrailing)

    static func avatarGradient(_ index: Int) -> LinearGradient {
        let pair = Profile.avatarColors[abs(index) % Profile.avatarColors.count]
        return LinearGradient(colors: [Color(hexString: pair.0), Color(hexString: pair.1)], startPoint: .topLeading, endPoint: .bottomTrailing)
    }
}

extension Color {
    init(hex: UInt32) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xFF) / 255,
            green: Double((hex >> 8) & 0xFF) / 255,
            blue: Double(hex & 0xFF) / 255,
            opacity: 1
        )
    }

    init(hexString: String) {
        let cleaned = hexString.trimmingCharacters(in: CharacterSet(charactersIn: "#"))
        self.init(hex: UInt32(cleaned, radix: 16) ?? 0x4F46E5)
    }
}

struct CardModifier: ViewModifier {
    var padding: CGFloat = 16
    func body(content: Content) -> some View {
        content
            .padding(padding)
            .background(Color.white)
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
            .shadow(color: Theme.ink.opacity(0.06), radius: 12, x: 0, y: 4)
    }
}

extension View {
    func card(padding: CGFloat = 16) -> some View { modifier(CardModifier(padding: padding)) }
}

struct SectionHeader: View {
    let title: String
    var body: some View {
        Text(title)
            .font(.system(size: 12, weight: .bold))
            .tracking(0.8)
            .foregroundStyle(Theme.faint)
            .frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct BrandButtonStyle: ButtonStyle {
    var color: Color = Theme.brand
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 15, weight: .semibold))
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(
                LinearGradient(colors: [color, color.opacity(0.85)], startPoint: .topLeading, endPoint: .bottomTrailing)
            )
            .clipShape(Capsule())
            .opacity(configuration.isPressed ? 0.85 : 1)
    }
}

struct TabWebView: UIViewRepresentable {
    let tab: BrowserTab

    func makeUIView(context: Context) -> WKWebView {
        tab.webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {}
}